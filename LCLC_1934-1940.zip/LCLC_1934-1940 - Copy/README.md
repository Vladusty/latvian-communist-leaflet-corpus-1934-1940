License

This corpus is distributed under the Creative Commons Attribution 4.0 International License (CC BY 4.0).

License: CC BY 4.0
https://creativecommons.org/licenses/by/4.0/